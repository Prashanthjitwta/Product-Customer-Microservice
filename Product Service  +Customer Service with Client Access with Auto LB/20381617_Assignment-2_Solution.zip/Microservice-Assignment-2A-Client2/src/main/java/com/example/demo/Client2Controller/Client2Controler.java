package com.example.demo.Client2Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Client2Entity.Client2Entity;

@RestController
public class Client2Controler {
	
	String url;
	@Autowired
	private RestTemplate template;
	
	@PostMapping("/insert-customer")
	public void insertCustomers(Model model,Client2Entity cliententity,
			@RequestParam("custId") int custId,
			@RequestParam("custName") String custName,
			@RequestParam("custaddress") String custaddress) {
		url = "http://Customer-Service/insert-customer";
		cliententity.setCustomerId(custId);
		cliententity.setCustomerName(custName);
		cliententity.setCustomerAddress(custaddress);
		template.postForEntity(url, cliententity, Client2Entity.class);
		}
	
	@GetMapping("displayAllCustomers")
	public String displayAllCustomers() {
		url = "http://Customer-Service/displayAllCustomer";
		return template.getForObject(url, String.class);
	}
	
	@GetMapping("display/{custId}")
	public String displayone(@PathVariable("custId") int custId) {
		url = "http://Customer-Service/display/"+custId;
		return template.getForObject(url, String.class);
	}
	
	@PutMapping("/update/{custId}")
	public void updateCustomers(Model model,Client2Entity cliententity,
			@RequestParam("custId") int custId,
			@RequestParam("custName") String custName,
			@RequestParam("custaddress") String custaddress) {
		url = "http://Customer-Service/update/"+custId;
		cliententity.setCustomerId(custId);
		cliententity.setCustomerName(custName);
		cliententity.setCustomerAddress(custaddress);
		template.put(url, cliententity, Client2Entity.class);
		}
	
	@DeleteMapping("delete/{custId}")
	public void delete(@PathVariable("custId") int custId) {
		url = "http://Customer-Service/delete/"+custId;
		template.delete(url);
	}
	
	@GetMapping("Costomer-Analysis")
	public String Costomeranalysis() {
		url = "http://Customer-Service/Costomer-Analysis/";
		return template.getForObject(url,String.class);
	}

}
