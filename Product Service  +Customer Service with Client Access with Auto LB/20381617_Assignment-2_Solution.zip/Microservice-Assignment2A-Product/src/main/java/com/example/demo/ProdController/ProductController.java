package com.example.demo.ProdController;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ProdEntity.ProductEntity;
import com.example.demo.ProdService.ProductService;

@RestController
@RefreshScope
public class ProductController {
	
	@Autowired
	private ProductService prodserv;
	
	@PostMapping("/insert-product")
	public void insertProducts(@RequestBody ProductEntity prodentity) {
		prodserv.saveNewRequest(prodentity);   
		}
	
	@GetMapping("/displayAllProducts")
	public List<ProductEntity> allProd() {
		return prodserv.displayall();
	}
	
	@GetMapping("/display/{prodId}")
	public List<ProductEntity> oneProd(@PathVariable("prodId") int prodId) {
		return prodserv.displaybyid(prodId);
	}
	
	@PutMapping("/update/{prodId}")
	public void update(@RequestBody ProductEntity prodentity) {
		prodserv.updatebyid(prodentity); 
	}
	
	@DeleteMapping("/delete/{prodId}")
	public void delete(@PathVariable("prodId") int prodId) {
		prodserv.deletebyid(prodId);
	}
	 
	@GetMapping("inventry-details")
	public String printstr() {
		String category = prodserv.category;
		String quantity = prodserv.quantity;
		String price1 = prodserv.price1;
		String price2 = prodserv.price2;
		String price3 = prodserv.price3;
		String discription = prodserv.discription;
	return "category:"+category+"\nquantity:"+quantity+"\nprice 1:"+price1+"\nprice 2:"+price2+
			"\nprice 3:"+price3+"\ndiscription:"+discription;
	}
}
