package com.example.demo.ProdService;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.example.demo.ProdEntity.ProductEntity;

@Service
public class ProductService {
	
	@Value("${product-category}")
	public String category;
	@Value("${product-quantity}")
	public String quantity;
	@Value("${product-1-price}")
	public String price1;
	@Value("${product-2-price}")
	public String price2;
	@Value("${product-3-price}")
	public String price3;
	@Value("${product-discription}")
	public String discription;
	
	
	List<ProductEntity> li = new ArrayList<ProductEntity>();
	HashMap<Integer,ProductEntity> map = new HashMap<Integer,ProductEntity>();
	
	public void saveNewRequest(ProductEntity prodentity) {
		map.put(prodentity.getProductId(),new ProductEntity(prodentity.getProductName(),prodentity.getProductId(),prodentity.getProductCategory()));
	}

	public List<ProductEntity> displayall() {
	//	map.forEach((k, v)-> System.out.println((v.getEmpId()+" "+v.getEmpName()+" "+v.getEmpEmail()+" "+v.getLocation())));
		Collection<ProductEntity> values = map.values(); 		         
		ArrayList<ProductEntity> listOfValues = new ArrayList<ProductEntity>(values);
		return listOfValues;
	}

	public List<ProductEntity> displaybyid(int prodId) {
		li.clear();
		li.add(map.get(prodId));
		return li;
	}
	
	public List<ProductEntity> updatebyid(ProductEntity prodentity) {
		map.replace(prodentity.getProductId(),new ProductEntity(prodentity.getProductName(),prodentity.getProductId(),prodentity.getProductCategory()));
		return li;
	}
	
	public void deletebyid(int prodId) {
		map.remove(prodId);
	}

}
