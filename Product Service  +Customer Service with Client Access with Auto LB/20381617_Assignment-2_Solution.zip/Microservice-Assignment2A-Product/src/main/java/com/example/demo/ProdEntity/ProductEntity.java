package com.example.demo.ProdEntity;

public class ProductEntity {
	
	private String productName;
	private int productId;
	private String productCategory;
	
	public ProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductEntity(String productName, int productId, String productCategory) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productCategory = productCategory;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
}
