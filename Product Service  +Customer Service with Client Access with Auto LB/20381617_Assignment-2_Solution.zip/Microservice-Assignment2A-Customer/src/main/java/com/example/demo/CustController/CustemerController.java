package com.example.demo.CustController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.CustEntity.CustomerEntity;
import com.example.demo.CustService.CustomerService;

@RestController
public class CustemerController {
	
	@Autowired
	private CustomerService custserv;
	
	@PostMapping("/insert-customer")
	public void insertCustomers(@RequestBody CustomerEntity custentity) {
		custserv.saveNewRequest(custentity);  
		}
	
	@GetMapping("/displayAllCustomer")
	public List<CustomerEntity> allCust() {
		return custserv.displayall();
	}
	
	@GetMapping("/display/{custId}")
	public List<CustomerEntity> oneCust(@PathVariable("custId") int custId) {
		return custserv.displaybyid(custId);
	}
	
	@PutMapping("/update/{custId}")
	public void update(@RequestBody CustomerEntity custentity) {
		custserv.updatebyid(custentity); 
	}
	
	@DeleteMapping("/delete/{custId}")
	public void delete(@PathVariable("custId") int custId) {
		custserv.deletebyid(custId);
	}
	
	@GetMapping("Costomer-Analysis")
	public String printstr() {
		String CustomerRating = custserv.CustomerRating;
		String NumberOfCustomers = custserv.NumberOfCustomers;
		String MinCustomerPurchase = custserv.MinCustomerPurchase;
		String PaymentMethod = custserv.PaymentMethod;
		String Description = custserv.Description;
	return "Customer-Rating:"+CustomerRating+"\nNumber-Of-Customers:"+NumberOfCustomers+
			"\nMin Customer Purchase:"+MinCustomerPurchase+"\nPayment Method:"+PaymentMethod+
			"\nDescription:"+Description;
	}	
}
