package com.example.demo.ClientEntity;

public class ClientEntity {
	
	private String productName;
	private int productId;
	private String productCategory;
	
	public ClientEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ClientEntity(String productName, int productId, String productCategory) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productCategory = productCategory;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

}
