package com.example.demo.ClientService;

import org.springframework.stereotype.Service;

@Service
public class ClientService {
}
