package com.example.demo.ClientController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example.demo.ClientEntity.ClientEntity;

@RestController
public class ClientController {
	
	String url;
	@Autowired
	private RestTemplate template;
	
	@PostMapping("/insert-product")
	public void insertProducts(Model model,ClientEntity cliententity,
			@RequestParam("prodId") int prodId,
			@RequestParam("prodName") String prodName,
			@RequestParam("prodCategory") String prodCategory) {
		url = "http://Product-Service/insert-product";
		cliententity.setProductId(prodId);
		cliententity.setProductName(prodName);
		cliententity.setProductCategory(prodCategory);
		template.postForEntity(url, cliententity, ClientEntity.class);
		}
	
	@GetMapping("displayAllProducts")
	public String displayAllProducts() {
		url = "http://Product-Service/displayAllProducts";
		return template.getForObject(url, String.class);
	}
	
	@GetMapping("display/{prodId}")
	public String displayone(@PathVariable("prodId") int prodId) {
		url = "http://Product-Service/display/"+prodId;
		return template.getForObject(url, String.class);
	}
	
	@PutMapping("/update/{prodId}")
	public void updateProducts(Model model,ClientEntity cliententity,
			@RequestParam("prodId") int prodId,
			@RequestParam("prodName") String prodName,
			@RequestParam("prodCategory") String prodCategory) {
		url = "http://Product-Service/update/"+prodId;
		cliententity.setProductId(prodId);
		cliententity.setProductName(prodName);
		cliententity.setProductCategory(prodCategory);
		template.put(url, cliententity, ClientEntity.class);
		}
	
	@DeleteMapping("delete/{prodId}")
	public void delete(@PathVariable("prodId") int prodId) {
		url = "http://Product-Service/delete/"+prodId;
		template.delete(url);
	}
	
	@GetMapping("inventry-details")
	public String inventrydetails() {
		url = "http://Product-Service/inventry-details/";
		return template.getForObject(url,String.class);
	}
}
